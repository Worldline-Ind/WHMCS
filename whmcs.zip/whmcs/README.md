# whmcs

Dowmload the zip and upload the files recursively into the whmcs installation directory

Also refer installation manual
